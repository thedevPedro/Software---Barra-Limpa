/**
 * Barra Limpa - Dados de Criminalidade Simulados
 * Baseado em padrões realistas de criminalidade urbana em São Paulo, SP
 * Categorias: furto, roubo, assalto, vandalismo, tráfico, homicídio
 */

const CRIME_CATEGORIES = {
    furto: { label: 'Furto', color: '#f39c12', icon: '🔓', weight: 2 },
    roubo: { label: 'Roubo', color: '#e67e22', icon: '💰', weight: 4 },
    assalto: { label: 'Assalto', color: '#e74c3c', icon: '🔪', weight: 5 },
    vandalismo: { label: 'Vandalismo', color: '#9b59b6', icon: '🔨', weight: 1 },
    trafico: { label: 'Tráfico de Drogas', color: '#8e44ad', icon: '💊', weight: 3 },
    homicidio: { label: 'Homicídio', color: '#c0392b', icon: '☠️', weight: 6 }
};

const SEVERITY_LEVELS = {
    low: { label: 'Baixo', color: '#2ecc71', min: 0, max: 30 },
    medium: { label: 'Médio', color: '#f1c40f', min: 31, max: 60 },
    high: { label: 'Alto', color: '#e67e22', min: 61, max: 80 },
    critical: { label: 'Crítico', color: '#e74c3c', min: 81, max: 100 }
};

/**
 * Zonas de risco em São Paulo
 * Cada zona tem: coordenadas centrais, raio de influência, tipos de crime, severidade, horários de pico
 */
const CRIME_ZONES = [
    // =========== ZONA CENTRAL ===========
    {
        id: 'cracolandia',
        name: 'Cracolândia / Luz',
        center: [-23.5338, -46.6350],
        radius: 500,
        crimes: ['trafico', 'assalto', 'roubo', 'furto'],
        severity: 95,
        peakHours: [0, 1, 2, 3, 4, 5, 22, 23],
        description: 'Região conhecida por alto índice de criminalidade e tráfico de drogas. Evitar especialmente à noite.'
    },
    {
        id: 'se_centro',
        name: 'Sé / Centro Histórico',
        center: [-23.5505, -46.6340],
        radius: 600,
        crimes: ['furto', 'roubo', 'assalto'],
        severity: 75,
        peakHours: [6, 7, 8, 17, 18, 19],
        description: 'Alto fluxo de pessoas em horários de pico. Furtos e arrastões são comuns.'
    },
    {
        id: 'republica',
        name: 'República',
        center: [-23.5436, -46.6424],
        radius: 400,
        crimes: ['furto', 'roubo', 'assalto'],
        severity: 70,
        peakHours: [18, 19, 20, 21, 22, 23],
        description: 'Região com alta incidência de furtos, especialmente no período noturno.'
    },
    {
        id: 'bras',
        name: 'Brás',
        center: [-23.5434, -46.6128],
        radius: 700,
        crimes: ['furto', 'roubo', 'vandalismo'],
        severity: 65,
        peakHours: [6, 7, 8, 9, 16, 17, 18],
        description: 'Comércio popular com aglomeração. Furtos frequentes em horário comercial.'
    },
    // =========== ZONA LESTE ===========
    {
        id: 'cidade_tiradentes',
        name: 'Cidade Tiradentes',
        center: [-23.5920, -46.4120],
        radius: 1200,
        crimes: ['assalto', 'homicidio', 'trafico', 'roubo'],
        severity: 90,
        peakHours: [20, 21, 22, 23, 0, 1, 2, 3],
        description: 'Região periférica com alto índice de violência e tráfico de drogas.'
    },
    {
        id: 'guaianases',
        name: 'Guaianases',
        center: [-23.5420, -46.4080],
        radius: 900,
        crimes: ['assalto', 'roubo', 'trafico'],
        severity: 82,
        peakHours: [19, 20, 21, 22, 23, 0],
        description: 'Região com elevados índices de assalto e roubo, principalmente à noite.'
    },
    {
        id: 'itaim_paulista',
        name: 'Itaim Paulista',
        center: [-23.4980, -46.3960],
        radius: 800,
        crimes: ['roubo', 'assalto', 'furto'],
        severity: 78,
        peakHours: [18, 19, 20, 21, 22],
        description: 'Altos índices de roubo e assaltos em vias públicas.'
    },
    {
        id: 'sao_mateus',
        name: 'São Mateus',
        center: [-23.6120, -46.4780],
        radius: 1000,
        crimes: ['assalto', 'roubo', 'trafico', 'homicidio'],
        severity: 85,
        peakHours: [20, 21, 22, 23, 0, 1],
        description: 'Alta incidência de crimes violentos nas vias secundárias.'
    },
    // =========== ZONA SUL ===========
    {
        id: 'capao_redondo',
        name: 'Capão Redondo',
        center: [-23.6680, -46.7780],
        radius: 1100,
        crimes: ['homicidio', 'trafico', 'assalto', 'roubo'],
        severity: 92,
        peakHours: [20, 21, 22, 23, 0, 1, 2],
        description: 'Uma das regiões com maiores índices de homicídio da cidade.'
    },
    {
        id: 'jardim_angela',
        name: 'Jardim Ângela',
        center: [-23.7240, -46.7560],
        radius: 1300,
        crimes: ['homicidio', 'trafico', 'assalto'],
        severity: 93,
        peakHours: [21, 22, 23, 0, 1, 2, 3],
        description: 'Historicamente uma das regiões mais violentas de São Paulo.'
    },
    {
        id: 'grajau',
        name: 'Grajaú',
        center: [-23.7560, -46.6960],
        radius: 1200,
        crimes: ['assalto', 'roubo', 'trafico', 'homicidio'],
        severity: 88,
        peakHours: [19, 20, 21, 22, 23, 0],
        description: 'Região periférica com alta criminalidade e poucos recursos de segurança.'
    },
    {
        id: 'parelheiros',
        name: 'Parelheiros',
        center: [-23.8280, -46.7320],
        radius: 1000,
        crimes: ['assalto', 'roubo', 'trafico'],
        severity: 80,
        peakHours: [20, 21, 22, 23, 0, 1],
        description: 'Região isolada com pouca iluminação e patrulhamento.'
    },
    // =========== ZONA NORTE ===========
    {
        id: 'brasilandia',
        name: 'Brasilândia',
        center: [-23.4720, -46.6760],
        radius: 900,
        crimes: ['trafico', 'assalto', 'roubo', 'homicidio'],
        severity: 84,
        peakHours: [20, 21, 22, 23, 0, 1],
        description: 'Região com alto índice de tráfico e violência associada.'
    },
    {
        id: 'cachoeirinha',
        name: 'Cachoeirinha',
        center: [-23.4620, -46.6490],
        radius: 700,
        crimes: ['roubo', 'furto', 'assalto'],
        severity: 72,
        peakHours: [18, 19, 20, 21, 22],
        description: 'Furtos e roubos frequentes, especialmente em transporte público.'
    },
    {
        id: 'jacanã',
        name: 'Jaçanã',
        center: [-23.4580, -46.5820],
        radius: 600,
        crimes: ['roubo', 'furto', 'vandalismo'],
        severity: 60,
        peakHours: [17, 18, 19, 20, 21],
        description: 'Roubos frequentes próximo a estações de trem.'
    },
    // =========== ZONA OESTE ===========
    {
        id: 'jaguare',
        name: 'Jaguaré',
        center: [-23.5280, -46.7450],
        radius: 500,
        crimes: ['roubo', 'furto', 'assalto'],
        severity: 62,
        peakHours: [18, 19, 20, 21, 22],
        description: 'Roubos de veículos e assaltos em vias pouco iluminadas.'
    },
    {
        id: 'raposo_tavares',
        name: 'Raposo Tavares',
        center: [-23.5960, -46.7890],
        radius: 800,
        crimes: ['roubo', 'furto', 'vandalismo'],
        severity: 58,
        peakHours: [19, 20, 21, 22, 23],
        description: 'Área com roubos de veículos e furtos a residências.'
    },
    // =========== VIAS CRÍTICAS ===========
    {
        id: 'marginal_tiete',
        name: 'Marginal Tietê (trecho central)',
        center: [-23.5130, -46.6280],
        radius: 400,
        crimes: ['roubo', 'furto', 'assalto'],
        severity: 68,
        peakHours: [0, 1, 2, 3, 4, 22, 23],
        description: 'Roubos de veículos parados no trânsito e assaltos em horários de menor movimento.'
    },
    {
        id: 'marginal_pinheiros',
        name: 'Marginal Pinheiros (trecho sul)',
        center: [-23.6120, -46.6980],
        radius: 400,
        crimes: ['roubo', 'furto'],
        severity: 55,
        peakHours: [22, 23, 0, 1, 2],
        description: 'Furtos em veículos parados no congestionamento.'
    },
    // =========== ÁREAS MAIS SEGURAS (para contraste) ===========
    {
        id: 'jardins',
        name: 'Jardins',
        center: [-23.5670, -46.6590],
        radius: 800,
        crimes: ['furto'],
        severity: 20,
        peakHours: [],
        description: 'Região nobre com boa iluminação e presença policial frequente.'
    },
    {
        id: 'moema',
        name: 'Moema',
        center: [-23.6010, -46.6640],
        radius: 700,
        crimes: ['furto'],
        severity: 15,
        peakHours: [],
        description: 'Bairro residencial de alto padrão com boa infraestrutura de segurança.'
    },
    {
        id: 'pinheiros',
        name: 'Pinheiros',
        center: [-23.5670, -46.6910],
        radius: 600,
        crimes: ['furto'],
        severity: 25,
        peakHours: [],
        description: 'Região com boa infraestrutura, comércio e segurança privada.'
    },
    {
        id: 'vila_mariana',
        name: 'Vila Mariana',
        center: [-23.5880, -46.6370],
        radius: 600,
        crimes: ['furto'],
        severity: 22,
        peakHours: [],
        description: 'Bairro residencial seguro com presença policial regular.'
    },
    {
        id: 'itaim_bibi',
        name: 'Itaim Bibi',
        center: [-23.5840, -46.6760],
        radius: 600,
        crimes: ['furto'],
        severity: 18,
        peakHours: [],
        description: 'Região empresarial com alto padrão de segurança.'
    }
];

/**
 * Gera pontos de calor (heatmap) baseados nas zonas de crime
 * Cada zona gera múltiplos pontos para criar um efeito realista
 */
function generateHeatmapPoints() {
    const points = [];
    
    CRIME_ZONES.forEach(zone => {
        const numPoints = Math.floor(zone.severity / 5) + 5;
        const radiusInDeg = zone.radius / 111000; // ~111km por grau

        for (let i = 0; i < numPoints; i++) {
            const angle = Math.random() * 2 * Math.PI;
            const r = Math.random() * radiusInDeg;
            const lat = zone.center[0] + r * Math.cos(angle);
            const lng = zone.center[1] + r * Math.sin(angle);
            const intensity = (zone.severity / 100) * (0.5 + Math.random() * 0.5);
            points.push([lat, lng, intensity]);
        }
    });

    return points;
}

/**
 * Analisa a segurança de um ponto específico
 * @param {number} lat - Latitude
 * @param {number} lng - Longitude
 * @returns {object} Análise de segurança do ponto
 */
function analyzePointSecurity(lat, lng) {
    let maxSeverity = 0;
    const nearbyZones = [];
    const currentHour = new Date().getHours();

    CRIME_ZONES.forEach(zone => {
        const distance = getDistanceFromLatLng(lat, lng, zone.center[0], zone.center[1]);
        
        if (distance <= zone.radius * 1.5) {
            const proximityFactor = 1 - (distance / (zone.radius * 1.5));
            let adjustedSeverity = zone.severity * proximityFactor;

            // Aumentar severidade em horários de pico
            if (zone.peakHours.includes(currentHour)) {
                adjustedSeverity *= 1.3;
            }

            adjustedSeverity = Math.min(100, adjustedSeverity);

            if (adjustedSeverity > maxSeverity) {
                maxSeverity = adjustedSeverity;
            }

            nearbyZones.push({
                ...zone,
                distance: Math.round(distance),
                adjustedSeverity: Math.round(adjustedSeverity),
                isPeakHour: zone.peakHours.includes(currentHour)
            });
        }
    });

    nearbyZones.sort((a, b) => b.adjustedSeverity - a.adjustedSeverity);

    return {
        severity: Math.round(maxSeverity),
        safetyScore: Math.round(100 - maxSeverity),
        level: getSeverityLevel(maxSeverity),
        nearbyZones: nearbyZones.slice(0, 3)
    };
}

/**
 * Analisa a segurança de uma rota inteira
 * @param {Array} routeCoords - Array de [lng, lat] da rota
 * @returns {object} Análise completa da rota
 */
function analyzeRouteSecurity(routeCoords) {
    if (!routeCoords || routeCoords.length === 0) {
        return { safetyScore: 50, level: 'medium', warnings: [], dangerousSegments: [] };
    }

    let totalSeverity = 0;
    let maxSeverity = 0;
    let sampleCount = 0;
    const warnings = [];
    const dangerousSegments = [];
    const encounteredZones = new Set();

    // Sample points along the route
    const step = Math.max(1, Math.floor(routeCoords.length / 50));

    for (let i = 0; i < routeCoords.length; i += step) {
        const coord = routeCoords[i];
        const lat = coord[1];
        const lng = coord[0];

        const analysis = analyzePointSecurity(lat, lng);
        totalSeverity += analysis.severity;
        sampleCount++;

        if (analysis.severity > maxSeverity) {
            maxSeverity = analysis.severity;
        }

        // Registrar zonas perigosas encontradas
        analysis.nearbyZones.forEach(zone => {
            if (zone.adjustedSeverity >= 40 && !encounteredZones.has(zone.id)) {
                encounteredZones.add(zone.id);

                const crimeLabels = zone.crimes.map(c => CRIME_CATEGORIES[c]?.label || c);

                warnings.push({
                    zoneId: zone.id,
                    zoneName: zone.name,
                    severity: zone.adjustedSeverity,
                    level: getSeverityLevel(zone.adjustedSeverity),
                    crimes: crimeLabels,
                    crimeIcons: zone.crimes.map(c => CRIME_CATEGORIES[c]?.icon || '⚠️'),
                    description: zone.description,
                    distance: zone.distance,
                    isPeakHour: zone.isPeakHour,
                    position: [lat, lng]
                });

                dangerousSegments.push({
                    center: [lat, lng],
                    zone: zone
                });
            }
        });
    }

    const avgSeverity = sampleCount > 0 ? totalSeverity / sampleCount : 0;
    // Weighted: 60% average, 40% max severity
    const weightedSeverity = avgSeverity * 0.6 + maxSeverity * 0.4;
    const safetyScore = Math.round(Math.max(0, Math.min(100, 100 - weightedSeverity)));

    warnings.sort((a, b) => b.severity - a.severity);

    return {
        safetyScore,
        level: getSeverityLevel(100 - safetyScore),
        avgSeverity: Math.round(avgSeverity),
        maxSeverity: Math.round(maxSeverity),
        warnings,
        dangerousSegments,
        zonesCount: encounteredZones.size
    };
}

// ===== UTILITÁRIOS =====

function getDistanceFromLatLng(lat1, lng1, lat2, lng2) {
    const R = 6371000; // Raio da Terra em metros
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
}

function getSeverityLevel(severity) {
    if (severity <= 30) return 'low';
    if (severity <= 60) return 'medium';
    if (severity <= 80) return 'high';
    return 'critical';
}

function getSeverityInfo(level) {
    return SEVERITY_LEVELS[level] || SEVERITY_LEVELS.medium;
}
