/**
 * Barra Limpa - Map Module
 * Gerenciamento do mapa Leaflet, marcadores, rotas e heatmap
 */

const MapManager = {
    map: null,
    markers: { origin: null, destination: null },
    routeLayers: [],
    heatLayer: null,
    dangerCircles: [],
    userLocationMarker: null,
    isHeatmapVisible: true,

    /**
     * Inicializar o mapa
     */
    init() {
        this.map = L.map('map', {
            center: [-23.5505, -46.6333], // São Paulo
            zoom: 13,
            zoomControl: false,
            attributionControl: true
        });

        // Dark tiles
        L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/">CARTO</a>',
            subdomains: 'abcd',
            maxZoom: 19
        }).addTo(this.map);

        // Zoom control at top-right
        L.control.zoom({ position: 'topright' }).addTo(this.map);

        // Inicializar heatmap
        this.initHeatmap();

        // Click no mapa para selecionar pontos
        this.map.on('click', (e) => {
            if (App.state.selectingPoint) {
                App.handleMapClick(e.latlng);
            }
        });

        return this;
    },

    /**
     * Inicializar camada de heatmap
     */
    initHeatmap() {
        const heatPoints = generateHeatmapPoints();

        this.heatLayer = L.heatLayer(heatPoints, {
            radius: 35,
            blur: 25,
            maxZoom: 17,
            max: 1.0,
            gradient: {
                0.0: '#00e676',
                0.25: '#66bb6a',
                0.4: '#ffca28',
                0.6: '#ff9100',
                0.8: '#ff1744',
                1.0: '#b71c1c'
            }
        }).addTo(this.map);
    },

    /**
     * Toggle heatmap visibility
     */
    toggleHeatmap(visible) {
        this.isHeatmapVisible = visible;
        if (visible) {
            this.heatLayer.addTo(this.map);
        } else {
            this.map.removeLayer(this.heatLayer);
        }
    },

    /**
     * Definir marcador de origem
     */
    setOriginMarker(lat, lng, label) {
        if (this.markers.origin) {
            this.map.removeLayer(this.markers.origin);
        }

        const icon = L.divIcon({
            className: 'custom-marker',
            html: `<div style="
                width: 20px; height: 20px; 
                background: #00d4aa; 
                border: 3px solid #fff; 
                border-radius: 50%; 
                box-shadow: 0 0 12px rgba(0,212,170,0.6);
            "></div>`,
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });

        this.markers.origin = L.marker([lat, lng], { icon })
            .addTo(this.map)
            .bindPopup(`<div class="popup-title">📍 Origem</div><div class="popup-subtitle">${label || ''}</div>`);

        return this;
    },

    /**
     * Definir marcador de destino
     */
    setDestinationMarker(lat, lng, label) {
        if (this.markers.destination) {
            this.map.removeLayer(this.markers.destination);
        }

        const icon = L.divIcon({
            className: 'custom-marker',
            html: `<div style="
                width: 20px; height: 20px; 
                background: #ff1744; 
                border: 3px solid #fff; 
                border-radius: 50%; 
                box-shadow: 0 0 12px rgba(255,23,68,0.6);
                position: relative;
            "></div>`,
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });

        this.markers.destination = L.marker([lat, lng], { icon })
            .addTo(this.map)
            .bindPopup(`<div class="popup-title">🏁 Destino</div><div class="popup-subtitle">${label || ''}</div>`);

        return this;
    },

    /**
     * Desenhar rotas no mapa
     * @param {Array} routes - Rotas calculadas
     * @param {Array} securityAnalyses - Análises de segurança de cada rota
     */
    drawRoutes(routes, securityAnalyses) {
        this.clearRoutes();

        const colors = {
            safe: '#00e676',
            moderate: '#ffca28',
            warning: '#ff9100',
            danger: '#ff1744'
        };

        routes.forEach((route, index) => {
            const analysis = securityAnalyses[index];
            const level = analysis ? analysis.level : 'moderate';
            const color = colors[level] || colors.moderate;
            const isActive = index === App.state.activeRouteIndex;

            // Convert [lng, lat] -> [lat, lng] for Leaflet
            const latLngs = route.coordinates.map(c => [c[1], c[0]]);

            // Shadow/outline layer
            const shadowLayer = L.polyline(latLngs, {
                color: '#000',
                weight: isActive ? 10 : 7,
                opacity: 0.3,
                lineCap: 'round',
                lineJoin: 'round'
            }).addTo(this.map);

            // Colored route layer
            const routeLayer = L.polyline(latLngs, {
                color: color,
                weight: isActive ? 7 : 4,
                opacity: isActive ? 1 : 0.55,
                lineCap: 'round',
                lineJoin: 'round',
                dashArray: isActive ? null : '8 6'
            }).addTo(this.map);

            routeLayer.on('click', () => {
                App.selectRoute(index);
            });

            routeLayer.on('mouseover', function () {
                if (index !== App.state.activeRouteIndex) {
                    this.setStyle({ opacity: 0.85, weight: 6 });
                }
            });

            routeLayer.on('mouseout', function () {
                if (index !== App.state.activeRouteIndex) {
                    this.setStyle({ opacity: 0.55, weight: 4 });
                }
            });

            this.routeLayers.push({ route: routeLayer, shadow: shadowLayer, index });
        });

        // Add danger circles for active route
        if (securityAnalyses[App.state.activeRouteIndex]) {
            this.drawDangerZones(securityAnalyses[App.state.activeRouteIndex]);
        }

        // Fit map to active route
        if (routes[App.state.activeRouteIndex]) {
            const activeLatLngs = routes[App.state.activeRouteIndex].coordinates.map(c => [c[1], c[0]]);
            this.map.fitBounds(L.latLng(activeLatLngs[0]).toBounds(100).extend(L.latLng(activeLatLngs[activeLatLngs.length - 1])), {
                padding: [80, 80]
            });
        }
    },

    /**
     * Highlight a specific route
     */
    highlightRoute(activeIndex) {
        const colors = {
            safe: '#00e676',
            moderate: '#ffca28',
            warning: '#ff9100',
            danger: '#ff1744'
        };

        this.routeLayers.forEach(({ route, shadow, index }) => {
            const isActive = index === activeIndex;
            const analysis = App.state.securityAnalyses[index];
            const level = analysis ? analysis.level : 'moderate';
            const color = colors[level] || colors.moderate;

            route.setStyle({
                weight: isActive ? 7 : 4,
                opacity: isActive ? 1 : 0.55,
                dashArray: isActive ? null : '8 6'
            });
            shadow.setStyle({
                weight: isActive ? 10 : 7
            });

            if (isActive) {
                route.bringToFront();
            }
        });
    },

    /**
     * Desenhar zonas de perigo no mapa
     */
    drawDangerZones(securityAnalysis) {
        this.clearDangerCircles();

        if (!securityAnalysis || !securityAnalysis.dangerousSegments) return;

        securityAnalysis.dangerousSegments.forEach(segment => {
            const zone = segment.zone;
            const color = zone.adjustedSeverity >= 80 ? '#ff1744' :
                zone.adjustedSeverity >= 60 ? '#ff9100' : '#ffca28';

            const circle = L.circle(segment.center, {
                radius: zone.radius || 300,
                color: color,
                fillColor: color,
                fillOpacity: 0.12,
                weight: 2,
                opacity: 0.5,
                dashArray: '5 5'
            }).addTo(this.map);

            circle.bindPopup(`
                <div class="popup-title">⚠️ ${zone.name}</div>
                <div class="popup-subtitle" style="margin-top:4px">${zone.description}</div>
            `);

            this.dangerCircles.push(circle);
        });
    },

    /**
     * Localização do usuário
     */
    locateUser() {
        return new Promise((resolve, reject) => {
            if (!navigator.geolocation) {
                reject(new Error('Geolocalização não suportada'));
                return;
            }

            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const { latitude, longitude } = position.coords;

                    if (this.userLocationMarker) {
                        this.map.removeLayer(this.userLocationMarker);
                    }

                    const icon = L.divIcon({
                        className: 'user-location-marker',
                        html: `<div style="
                            width: 16px; height: 16px;
                            background: #4285f4;
                            border: 3px solid #fff;
                            border-radius: 50%;
                            box-shadow: 0 0 0 8px rgba(66,133,244,0.2), 0 0 16px rgba(66,133,244,0.4);
                            animation: pulse 2s infinite;
                        "></div>`,
                        iconSize: [16, 16],
                        iconAnchor: [8, 8]
                    });

                    this.userLocationMarker = L.marker([latitude, longitude], { icon })
                        .addTo(this.map)
                        .bindPopup('<div class="popup-title">📍 Sua localização</div>');

                    this.map.setView([latitude, longitude], 15);

                    resolve({ lat: latitude, lng: longitude });
                },
                (error) => {
                    reject(error);
                }
            );
        });
    },

    clearRoutes() {
        this.routeLayers.forEach(({ route, shadow }) => {
            this.map.removeLayer(route);
            this.map.removeLayer(shadow);
        });
        this.routeLayers = [];
        this.clearDangerCircles();
    },

    clearDangerCircles() {
        this.dangerCircles.forEach(c => this.map.removeLayer(c));
        this.dangerCircles = [];
    },

    clearAll() {
        this.clearRoutes();
        if (this.markers.origin) {
            this.map.removeLayer(this.markers.origin);
            this.markers.origin = null;
        }
        if (this.markers.destination) {
            this.map.removeLayer(this.markers.destination);
            this.markers.destination = null;
        }
    },

    /**
     * Fit map para mostrar origem e destino
     */
    fitBoundsToMarkers() {
        const points = [];
        if (this.markers.origin) points.push(this.markers.origin.getLatLng());
        if (this.markers.destination) points.push(this.markers.destination.getLatLng());

        if (points.length === 2) {
            const bounds = L.latLngBounds(points);
            this.map.fitBounds(bounds, { padding: [80, 80] });
        } else if (points.length === 1) {
            this.map.setView(points[0], 15);
        }
    }
};
