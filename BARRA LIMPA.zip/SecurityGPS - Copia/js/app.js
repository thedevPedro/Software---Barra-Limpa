/*
 * Barra Limpa - Main Application
 * Orquestra todos os módulos: mapa, rotas, geocoding, segurança, UI
 */

const App = {
    state: {
        origin: null,           // { lat, lng, name }
        destination: null,      // { lat, lng, name }
        routes: [],             // Rotas calculadas
        securityAnalyses: [],   // Análise de segurança de cada rota
        activeRouteIndex: 0,    // Rota selecionada
        selectingPoint: null,   // 'origin' | 'destination' | null
        autocompleteResults: { origin: [], destination: [] }
    },

    /**
     * Inicializar aplicação
     */
    init() {
        MapManager.init();
        UI.init();
        this.setupEventListeners();
        this.setupClickToSelect();

        UI.showToast('Bem-vindo ao Barra Limpa! Busque uma rota para começar.', 'info', 5000);
    },

    /**
     * Configurar event listeners
     */
    setupEventListeners() {
        // Origin input
        UI.elements.originInput.addEventListener('input', (e) => {
            const query = e.target.value.trim();
            GeocodingService.searchDebounced(query, (results) => {
                this.state.autocompleteResults.origin = results;
                UI.showAutocomplete(UI.elements.originDropdown, results);
            });
        });

        // Destination input
        UI.elements.destInput.addEventListener('input', (e) => {
            const query = e.target.value.trim();
            GeocodingService.searchDebounced(query, (results) => {
                this.state.autocompleteResults.destination = results;
                UI.showAutocomplete(UI.elements.destDropdown, results);
            });
        });

        // Origin autocomplete click
        UI.elements.originDropdown.addEventListener('click', (e) => {
            const item = e.target.closest('.autocomplete-item');
            if (!item) return;
            const index = parseInt(item.dataset.index);
            const result = this.state.autocompleteResults.origin[index];
            if (result) {
                this.setOrigin(result.lat, result.lng, result.shortName || result.name);
                UI.elements.originInput.value = result.shortName || result.name;
                UI.hideAutocomplete(UI.elements.originDropdown);
            }
        });

        // Destination autocomplete click
        UI.elements.destDropdown.addEventListener('click', (e) => {
            const item = e.target.closest('.autocomplete-item');
            if (!item) return;
            const index = parseInt(item.dataset.index);
            const result = this.state.autocompleteResults.destination[index];
            if (result) {
                this.setDestination(result.lat, result.lng, result.shortName || result.name);
                UI.elements.destInput.value = result.shortName || result.name;
                UI.hideAutocomplete(UI.elements.destDropdown);
            }
        });

        // Search button
        UI.elements.searchBtn.addEventListener('click', () => {
            this.calculateRoutes();
        });

        // Clear button
        UI.elements.clearBtn.addEventListener('click', () => {
            this.clearAll();
        });

        // Heatmap toggle
        UI.elements.heatmapToggle.addEventListener('change', (e) => {
            MapManager.toggleHeatmap(e.target.checked);
        });

        // Enter key on inputs
        UI.elements.originInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                UI.hideAllAutocomplete();
                if (this.state.origin && this.state.destination) {
                    this.calculateRoutes();
                } else {
                    UI.elements.destInput.focus();
                }
            }
        });

        UI.elements.destInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                UI.hideAllAutocomplete();
                if (this.state.origin && this.state.destination) {
                    this.calculateRoutes();
                }
            }
        });

        // Close dropdowns when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.search-group')) {
                UI.hideAllAutocomplete();
            }
        });

        // Clear buttons
        document.querySelectorAll('.search-clear').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const input = e.target.closest('.search-input-wrapper').querySelector('.search-input');
                input.value = '';
                input.focus();
                const type = input.id === 'originInput' ? 'origin' : 'destination';
                if (type === 'origin') {
                    this.state.origin = null;
                } else {
                    this.state.destination = null;
                }
                this.updateSearchButtonState();
            });
        });

        // GPS button
        document.getElementById('gpsBtn').addEventListener('click', () => {
            this.handleGPS();
        });

        // Swap button
        document.getElementById('swapBtn').addEventListener('click', () => {
            this.swapOriginDestination();
        });

        // Legend button
        document.getElementById('legendBtn').addEventListener('click', () => {
            const legend = document.getElementById('legendPanel');
            legend.classList.toggle('hidden');
        });
    },

    /**
     * Setup click-to-select on map
     */
    setupClickToSelect() {
        // Nothing needed - handled by the map click listener in MapManager
    },

    /**
     * Handle GPS location
     */
    async handleGPS() {
        try {
            UI.showToast('Obtendo sua localização...', 'info', 2000);
            const location = await MapManager.locateUser();
            const address = await GeocodingService.reverse(location.lat, location.lng);

            if (address) {
                this.setOrigin(location.lat, location.lng, address.shortName);
                UI.elements.originInput.value = address.shortName;
                UI.showToast('Localização definida como origem!', 'success');
            } else {
                this.setOrigin(location.lat, location.lng, 'Minha localização');
                UI.elements.originInput.value = 'Minha localização';
            }
        } catch (error) {
            UI.showToast('Não foi possível obter sua localização. Verifique as permissões.', 'error');
        }
    },

    /**
     * Handle map click
     */
    async handleMapClick(latlng) {
        const addr = await GeocodingService.reverse(latlng.lat, latlng.lng);
        const name = addr ? addr.shortName : `${latlng.lat.toFixed(4)}, ${latlng.lng.toFixed(4)}`;

        if (!this.state.origin) {
            this.setOrigin(latlng.lat, latlng.lng, name);
            UI.elements.originInput.value = name;
            UI.showToast('Origem definida! Agora defina o destino.', 'success', 3000);
        } else if (!this.state.destination) {
            this.setDestination(latlng.lat, latlng.lng, name);
            UI.elements.destInput.value = name;
            UI.showToast('Destino definido!', 'success', 2000);
            // Auto calculate
            setTimeout(() => this.calculateRoutes(), 500);
        }
    },

    /**
     * Set origin point
     */
    setOrigin(lat, lng, name) {
        this.state.origin = { lat, lng, name };
        MapManager.setOriginMarker(lat, lng, name);
        this.updateSearchButtonState();
    },

    /**
     * Set destination point
     */
    setDestination(lat, lng, name) {
        this.state.destination = { lat, lng, name };
        MapManager.setDestinationMarker(lat, lng, name);
        MapManager.fitBoundsToMarkers();
        this.updateSearchButtonState();
    },

    /**
     * Swap origin and destination
     */
    swapOriginDestination() {
        const temp = this.state.origin;
        this.state.origin = this.state.destination;
        this.state.destination = temp;

        const tempVal = UI.elements.originInput.value;
        UI.elements.originInput.value = UI.elements.destInput.value;
        UI.elements.destInput.value = tempVal;

        if (this.state.origin) {
            MapManager.setOriginMarker(this.state.origin.lat, this.state.origin.lng, this.state.origin.name);
        }
        if (this.state.destination) {
            MapManager.setDestinationMarker(this.state.destination.lat, this.state.destination.lng, this.state.destination.name);
        }

        if (this.state.routes.length > 0) {
            this.calculateRoutes();
        }
    },

    /**
     * Calculate routes
     */
    async calculateRoutes() {
        if (!this.state.origin || !this.state.destination) {
            UI.showToast('Defina origem e destino para calcular rotas.', 'warning');
            return;
        }

        UI.showLoading('Calculando rotas seguras...');
        MapManager.clearRoutes();

        try {
            // Get routes
            const routes = await RoutingService.getRoutes(this.state.origin, this.state.destination);

            if (!routes || routes.length === 0) {
                throw new Error('Nenhuma rota encontrada');
            }

            this.state.routes = routes;

            // Analyze security for each route
            this.state.securityAnalyses = routes.map(route => {
                return analyzeRouteSecurity(route.coordinates);
            });

            // Select safest route by default
            let bestIndex = 0;
            let bestScore = -1;
            this.state.securityAnalyses.forEach((a, i) => {
                if (a.safetyScore > bestScore) {
                    bestScore = a.safetyScore;
                    bestIndex = i;
                }
            });
            this.state.activeRouteIndex = bestIndex;

            // Draw on map
            MapManager.drawRoutes(routes, this.state.securityAnalyses);

            // Update UI
            UI.showRoutes(routes, this.state.securityAnalyses);
            UI.hideLoading();

            const bestAnalysis = this.state.securityAnalyses[bestIndex];
            if (bestAnalysis.warnings.length > 0) {
                UI.showToast(`${routes.length} rotas encontradas. A mais segura tem ${bestAnalysis.warnings.length} alerta(s).`, 'warning', 5000);
            } else {
                UI.showToast(`${routes.length} rotas encontradas. Rota recomendada é segura!`, 'success', 4000);
            }

        } catch (error) {
            UI.hideLoading();
            UI.showToast(error.message || 'Erro ao calcular rotas. Tente novamente.', 'error');
            console.error('Route calculation error:', error);
        }
    },

    /**
     * Select a specific route
     */
    selectRoute(index) {
        this.state.activeRouteIndex = index;
        MapManager.highlightRoute(index);
        MapManager.drawDangerZones(this.state.securityAnalyses[index]);
        UI.showRoutes(this.state.routes, this.state.securityAnalyses);
    },

    /**
     * Clear everything
     */
    clearAll() {
        this.state.origin = null;
        this.state.destination = null;
        this.state.routes = [];
        this.state.securityAnalyses = [];
        this.state.activeRouteIndex = 0;

        UI.elements.originInput.value = '';
        UI.elements.destInput.value = '';
        UI.showEmptyState();
        MapManager.clearAll();
        this.updateSearchButtonState();

        UI.showToast('Tudo limpo! Comece uma nova busca.', 'info', 3000);
    },

    updateSearchButtonState() {
        const enabled = this.state.origin && this.state.destination;
        UI.updateSearchButton(enabled);
    }
};

// Init when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});
