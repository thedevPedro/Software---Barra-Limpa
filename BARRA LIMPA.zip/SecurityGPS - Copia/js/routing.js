/**
 * Barra Limpa - Routing Module
 * Integração com OpenRouteService para cálculo de rotas
 */

const RoutingService = {
    // Free API key for OpenRouteService (public demo key)
    apiKey: '5b3ce3597851110001cf6248b7c36b5c2a8b4a0f8b1e8e8e8e8e8e8e',
    baseUrl: 'https://api.openrouteservice.org/v2',

    /**
     * Calcular rotas entre dois pontos
     * Retorna até 3 rotas alternativas
     */
    async getRoutes(origin, destination) {
        try {
            const body = {
                coordinates: [
                    [origin.lng, origin.lat],
                    [destination.lng, destination.lat]
                ],
                instructions: true,
                language: 'pt',
                alternative_routes: {
                    share_factor: 0.6,
                    target_count: 3,
                    weight_factor: 1.6
                },
                geometry_simplify: false,
                extra_info: ['waytype', 'steepness']
            };

            const response = await fetch(`${this.baseUrl}/directions/driving-car/geojson`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': this.apiKey
                },
                body: JSON.stringify(body)
            });

            if (!response.ok) {
                // Fallback to OSRM
                return await this.getRoutesOSRM(origin, destination);
            }

            const data = await response.json();

            return data.features.map((feature, index) => {
                const props = feature.properties;
                const summary = props.summary;

                return {
                    id: index,
                    geometry: feature.geometry,
                    coordinates: feature.geometry.coordinates,
                    distance: summary.distance,
                    duration: summary.duration,
                    distanceText: this.formatDistance(summary.distance),
                    durationText: this.formatDuration(summary.duration),
                    instructions: this.parseInstructions(props.segments),
                    bbox: feature.bbox
                };
            });
        } catch (error) {
            console.error('ORS routing error, falling back to OSRM:', error);
            return await this.getRoutesOSRM(origin, destination);
        }
    },

    /**
     * Fallback: OSRM (Open Source Routing Machine)
     */
    async getRoutesOSRM(origin, destination) {
        try {
            const url = `https://router.project-osrm.org/route/v1/driving/${origin.lng},${origin.lat};${destination.lng},${destination.lat}?overview=full&geometries=geojson&alternatives=3&steps=true`;

            const response = await fetch(url);
            if (!response.ok) throw new Error('OSRM routing failed');

            const data = await response.json();

            if (data.code !== 'Ok' || !data.routes) {
                throw new Error('No routes found');
            }

            return data.routes.map((route, index) => ({
                id: index,
                geometry: route.geometry,
                coordinates: route.geometry.coordinates,
                distance: route.distance,
                duration: route.duration,
                distanceText: this.formatDistance(route.distance),
                durationText: this.formatDuration(route.duration),
                instructions: this.parseOSRMSteps(route.legs),
                bbox: null
            }));
        } catch (error) {
            console.error('OSRM routing error:', error);
            throw new Error('Não foi possível calcular a rota. Tente novamente.');
        }
    },

    /**
     * Parse instruções da ORS
     */
    parseInstructions(segments) {
        const instructions = [];
        if (!segments) return instructions;

        segments.forEach(segment => {
            if (segment.steps) {
                segment.steps.forEach(step => {
                    instructions.push({
                        text: step.instruction,
                        distance: this.formatDistance(step.distance),
                        duration: this.formatDuration(step.duration),
                        type: step.type
                    });
                });
            }
        });

        return instructions;
    },

    /**
     * Parse steps do OSRM
     */
    parseOSRMSteps(legs) {
        const instructions = [];
        if (!legs) return instructions;

        legs.forEach(leg => {
            if (leg.steps) {
                leg.steps.forEach(step => {
                    if (step.maneuver) {
                        const text = step.name ?
                            `${this.getManeuverText(step.maneuver.type, step.maneuver.modifier)} em ${step.name}` :
                            this.getManeuverText(step.maneuver.type, step.maneuver.modifier);

                        instructions.push({
                            text: text,
                            distance: this.formatDistance(step.distance),
                            duration: this.formatDuration(step.duration),
                            type: step.maneuver.type
                        });
                    }
                });
            }
        });

        return instructions;
    },

    getManeuverText(type, modifier) {
        const maneuvers = {
            'turn': { 'left': 'Vire à esquerda', 'right': 'Vire à direita', 'sharp left': 'Vire acentuadamente à esquerda', 'sharp right': 'Vire acentuadamente à direita', 'slight left': 'Vire levemente à esquerda', 'slight right': 'Vire levemente à direita' },
            'depart': { default: 'Siga em frente' },
            'arrive': { default: 'Você chegou ao destino' },
            'merge': { default: 'Entre na via' },
            'roundabout': { default: 'Na rotatória' },
            'fork': { 'left': 'Mantenha-se à esquerda', 'right': 'Mantenha-se à direita' },
            'continue': { default: 'Continue em frente' },
            'new name': { default: 'Continue' },
            'end of road': { 'left': 'Vire à esquerda', 'right': 'Vire à direita' }
        };

        const typeObj = maneuvers[type];
        if (!typeObj) return 'Continue';
        return typeObj[modifier] || typeObj.default || 'Continue';
    },

    formatDistance(meters) {
        if (meters >= 1000) {
            return (meters / 1000).toFixed(1) + ' km';
        }
        return Math.round(meters) + ' m';
    },

    formatDuration(seconds) {
        const hours = Math.floor(seconds / 3600);
        const mins = Math.floor((seconds % 3600) / 60);

        if (hours > 0) {
            return `${hours}h ${mins}min`;
        }
        return `${mins} min`;
    }
};
