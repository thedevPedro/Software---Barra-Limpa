/*
 * Barra Limpa - UI Module
 * Gerencia componentes de interface: painel lateral, cards de rota, toasts
 */

const UI = {
    elements: {},

    init() {
        this.elements = {
            originInput: document.getElementById('originInput'),
            destInput: document.getElementById('destInput'),
            originDropdown: document.getElementById('originDropdown'),
            destDropdown: document.getElementById('destDropdown'),
            routesPanel: document.getElementById('routesPanel'),
            routesList: document.getElementById('routesList'),
            emptyState: document.getElementById('emptyState'),
            detailPanel: document.getElementById('detailPanel'),
            detailContent: document.getElementById('detailContent'),
            loadingOverlay: document.getElementById('loadingOverlay'),
            toastContainer: document.getElementById('toastContainer'),
            searchBtn: document.getElementById('searchBtn'),
            clearBtn: document.getElementById('clearBtn'),
            heatmapToggle: document.getElementById('heatmapToggle')
        };
    },

    // ===== AUTOCOMPLETE =====
    showAutocomplete(dropdownEl, results) {
        if (!results || results.length === 0) {
            dropdownEl.classList.remove('visible');
            return;
        }

        dropdownEl.innerHTML = results.map((r, i) => `
            <div class="autocomplete-item" data-index="${i}">
                <span class="icon">📍</span>
                <span class="text">${r.shortName || r.name}</span>
            </div>
        `).join('');

        dropdownEl.classList.add('visible');
    },

    hideAutocomplete(dropdownEl) {
        dropdownEl.classList.remove('visible');
    },

    hideAllAutocomplete() {
        this.elements.originDropdown.classList.remove('visible');
        this.elements.destDropdown.classList.remove('visible');
    },

    // ===== LOADING =====
    showLoading(text = 'Calculando rotas seguras...') {
        const overlay = this.elements.loadingOverlay;
        overlay.querySelector('.loading-text').textContent = text;
        overlay.classList.add('visible');
    },

    hideLoading() {
        this.elements.loadingOverlay.classList.remove('visible');
    },

    // ===== TOAST NOTIFICATIONS =====
    showToast(message, type = 'info', duration = 4000) {
        const icons = {
            success: '✅',
            warning: '⚠️',
            error: '❌',
            info: 'ℹ️'
        };

        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <span class="toast-icon">${icons[type]}</span>
            <span class="toast-message">${message}</span>
            <button class="toast-close" onclick="this.parentElement.remove()">✕</button>
        `;

        this.elements.toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(60px)';
            toast.style.transition = 'all 300ms';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    },

    // ===== ROUTES DISPLAY =====
    showRoutes(routes, securityAnalyses) {
        this.elements.emptyState.style.display = 'none';
        this.elements.routesList.style.display = 'block';

        // Find best safety score
        let bestIndex = 0;
        let bestScore = -1;
        securityAnalyses.forEach((a, i) => {
            if (a.safetyScore > bestScore) {
                bestScore = a.safetyScore;
                bestIndex = i;
            }
        });

        this.elements.routesList.innerHTML = `
            <div class="section-header">
                <h2>Rotas Encontradas</h2>
                <span class="badge" style="background: var(--primary-glow); color: var(--primary);">${routes.length} opções</span>
            </div>
            ${routes.map((route, index) => {
            const analysis = securityAnalyses[index];
            const levelClass = this.getSafetyClass(analysis.level);
            const isActive = index === App.state.activeRouteIndex;
            const isRecommended = index === bestIndex;

            return `
                <div class="route-card ${levelClass} ${isActive ? 'active' : ''} ${isRecommended ? 'recommended' : ''}" 
                     data-route-index="${index}" onclick="App.selectRoute(${index})">
                    ${isRecommended ? '<div class="route-card-badge">✦ RECOMENDADA</div>' : ''}
                    <div class="route-card-header">
                        <div class="route-card-number">${index + 1}</div>
                        <div class="route-card-title">
                            <h3>Rota ${index + 1}</h3>
                            <span>${route.distanceText} · ${route.durationText}</span>
                        </div>
                    </div>
                    <div class="route-stats">
                        <div class="route-stat">
                            <div class="route-stat-value">${route.durationText}</div>
                            <div class="route-stat-label">Tempo</div>
                        </div>
                        <div class="route-stat">
                            <div class="route-stat-value">${route.distanceText}</div>
                            <div class="route-stat-label">Distância</div>
                        </div>
                        <div class="route-stat">
                            <div class="route-stat-value">${analysis.safetyScore}</div>
                            <div class="route-stat-label">Segurança</div>
                        </div>
                    </div>
                    <div class="safety-bar">
                        <div class="safety-bar-fill ${levelClass}" style="width: ${analysis.safetyScore}%"></div>
                    </div>
                    <span class="safety-label ${levelClass}">
                        ${this.getSafetyText(analysis.level)} · ${analysis.warnings.length} alerta${analysis.warnings.length !== 1 ? 's' : ''}
                    </span>
                </div>
                `;
        }).join('')}

            ${this.renderWarningsSummary(securityAnalyses[App.state.activeRouteIndex])}
        `;
    },

    renderWarningsSummary(analysis) {
        if (!analysis || !analysis.warnings || analysis.warnings.length === 0) {
            return `
                <div class="warnings-section animate-slide-up">
                    <div class="section-header">
                        <h2>Análise de Segurança</h2>
                    </div>
                    <div class="warning-card" style="text-align:center; padding: 24px;">
                        <span style="font-size: 32px; display: block; margin-bottom: 8px;">🛡️</span>
                        <p style="color: var(--safe); font-weight: 600; margin-bottom: 4px;">Rota Segura!</p>
                        <p style="font-size: 12px; color: var(--text-muted);">Esta rota não passa por zonas de risco identificadas.</p>
                    </div>
                </div>
            `;
        }

        return `
            <div class="warnings-section animate-slide-up">
                <div class="section-header">
                    <h2>⚠️ Alertas de Segurança</h2>
                    <span class="badge" style="background: var(--danger-bg); color: var(--danger);">${analysis.warnings.length}</span>
                </div>
                ${analysis.warnings.map(w => `
                    <div class="warning-card severity-${w.level}">
                        <div class="warning-card-header">
                            <span class="warning-card-icon">${w.crimeIcons[0] || '⚠️'}</span>
                            <div class="warning-card-title">
                                <h4>${w.zoneName} <span class="severity-tag ${w.level}">${this.getSafetyText(w.level)}</span></h4>
                            </div>
                        </div>
                        <div class="warning-card-body">
                            ${w.description}
                        </div>
                        <div class="warning-card-crimes">
                            ${w.crimes.map((crime, i) => `
                                <span class="crime-tag">${w.crimeIcons[i] || '⚠️'} ${crime}</span>
                            `).join('')}
                        </div>
                        ${w.isPeakHour ? '<div class="peak-badge">🕐 Horário de pico de ocorrências</div>' : ''}
                    </div>
                `).join('')}
            </div>
        `;
    },

    showEmptyState() {
        this.elements.emptyState.style.display = 'flex';
        this.elements.routesList.style.display = 'none';
    },

    // ===== HELPERS =====
    getSafetyClass(level) {
        const map = { low: 'safe', medium: 'moderate', high: 'warning', critical: 'danger' };
        return map[level] || 'moderate';
    },

    getSafetyText(level) {
        const map = { low: 'Seguro', medium: 'Moderado', high: 'Alto Risco', critical: 'Crítico' };
        return map[level] || 'Moderado';
    },

    updateSearchButton(enabled) {
        this.elements.searchBtn.disabled = !enabled;
    }
};
