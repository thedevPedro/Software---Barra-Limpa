/**
 * Barra Limpa - Geocoding Module
 * Integração com Nominatim (OpenStreetMap) para busca de endereços
 */

const GeocodingService = {
    baseUrl: 'https://nominatim.openstreetmap.org',
    debounceTimer: null,
    debounceDelay: 400,

    /**
     * Buscar endereços por texto
     * @param {string} query - Texto de busca
     * @returns {Promise<Array>} Lista de resultados
     */
    async search(query) {
        if (!query || query.length < 3) return [];

        try {
            const params = new URLSearchParams({
                q: query,
                format: 'json',
                addressdetails: 1,
                limit: 6,
                countrycodes: 'br',
                viewbox: '-47.2,-24.1,-46.0,-23.2', // São Paulo region
                bounded: 0
            });

            const response = await fetch(`${this.baseUrl}/search?${params}`, {
                headers: {
                    'Accept-Language': 'pt-BR'
                }
            });

            if (!response.ok) throw new Error('Geocoding failed');

            const data = await response.json();

            return data.map(item => ({
                id: item.place_id,
                name: item.display_name,
                shortName: this.formatShortName(item),
                lat: parseFloat(item.lat),
                lng: parseFloat(item.lon),
                type: item.type,
                address: item.address
            }));
        } catch (error) {
            console.error('Geocoding error:', error);
            return [];
        }
    },

    /**
     * Geocodificação reversa (coordenadas -> endereço)
     */
    async reverse(lat, lng) {
        try {
            const params = new URLSearchParams({
                lat: lat,
                lon: lng,
                format: 'json',
                addressdetails: 1
            });

            const response = await fetch(`${this.baseUrl}/reverse?${params}`, {
                headers: { 'Accept-Language': 'pt-BR' }
            });

            if (!response.ok) throw new Error('Reverse geocoding failed');

            const data = await response.json();

            return {
                name: data.display_name,
                shortName: this.formatShortName(data),
                lat: parseFloat(data.lat),
                lng: parseFloat(data.lon),
                address: data.address
            };
        } catch (error) {
            console.error('Reverse geocoding error:', error);
            return null;
        }
    },

    /**
     * Formata nome curto do endereço
     */
    formatShortName(item) {
        const addr = item.address || {};
        const parts = [];

        if (addr.road) parts.push(addr.road);
        if (addr.house_number) parts[parts.length - 1] += ', ' + addr.house_number;
        if (addr.suburb) parts.push(addr.suburb);
        if (addr.city || addr.town) parts.push(addr.city || addr.town);

        return parts.length > 0 ? parts.join(' - ') : item.display_name?.split(',').slice(0, 3).join(',');
    },

    /**
     * Busca com debounce para autocomplete
     */
    searchDebounced(query, callback) {
        clearTimeout(this.debounceTimer);

        if (!query || query.length < 3) {
            callback([]);
            return;
        }

        this.debounceTimer = setTimeout(async () => {
            const results = await this.search(query);
            callback(results);
        }, this.debounceDelay);
    }
};
